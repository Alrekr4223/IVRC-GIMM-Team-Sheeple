﻿using UnityEngine;
using System.Collections;

public class GravityAttractor : MonoBehaviour 
{
	public Vector3 m_GravitationalCenter;
	public float m_GravitationalConstant = -9.8f;

	//private float pullForce = -9.8f;


	// Use this for initialization
	void Start () 
	{
		m_GravitationalCenter = gameObject.transform.position;
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
		
	public void AttractSheep (Rigidbody body) 
	{
		Vector3 pullVector = findSurface (body);
		orientBody (body, pullVector);

		float pullForce = 0;
		pullForce = -1000f;
		//pullForce = m_GravitationalConstant * (

		pullVector = body.transform.position - m_GravitationalCenter;
		body.AddForce (pullVector.normalized * pullForce * Time.deltaTime);
	}
	private Vector3 findSurface(Rigidbody body) 
	{
		float distance = Vector3.Distance (this.transform.position, body.transform.position); // get distance between object and attractor
		Vector3 surfaceNormal = Vector3.zero;

		RaycastHit hit;
		if (Physics.Raycast (body.transform.position, -body.transform.up, out hit, distance)) 
		{
			surfaceNormal = hit.normal;
		}
		return surfaceNormal;
	}
	private void orientBody(Rigidbody body, Vector3 surfaceNormal) 
	{
		body.transform.localRotation = Quaternion.FromToRotation (body.transform.up, surfaceNormal) * body.rotation;
	}
}
