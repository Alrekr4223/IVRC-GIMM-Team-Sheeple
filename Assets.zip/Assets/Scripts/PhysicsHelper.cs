﻿using UnityEngine;
using System.Collections;

public class PhysicsHelper : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		/*for (int i = 0; i < GameObject.Find("SheepController").transform.childCount; i++) 
		{
			Debug.Log (i);
			GameObject child = gameObject.transform.GetChild (0).GetChild(i).gameObject;
			child.transform.rotation = gameObject.transform.rotation; 
		}*/
	}
}
