﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SheepController : MonoBehaviour {

	public GameObject m_SheepPrefab;
	public GameObject m_Planet;
	public int m_SheepCount = 20;

	private List<Sheep> m_SheepList;
	private enum m_SheepDesireEnum {Fluffness, Love, No_Predators};
	// Use this for initialization
	void Start () 
	{
		for (int i = 0; i < m_SheepCount; i++) 
		{
			GameObject sheepGameObject = Instantiate (m_SheepPrefab);
			sheepGameObject.transform.position = new Vector3 (50f, Random.value * 50f, Random.value * 50f);
			sheepGameObject.transform.parent = gameObject.transform;

			sheepGameObject.AddComponent<Sheep> ();
			//sheepGameObject.AddComponent<Rigidbody> ();
			//sheepGameObject.GetComponent<MeshRenderer>().material.color = Color.red;
			sheepGameObject.GetComponent<GravityBody> ().m_CurrentAttraction = GameObject.Find ("Planet").GetComponent<GravityAttractor> ();
			Sheep sheepInfo = sheepGameObject.GetComponent<Sheep> ();
			m_SheepDesireEnum sheepDesireNum;
			sheepDesireNum = (m_SheepDesireEnum)Random.Range(0, 2);
			sheepInfo.m_DesireIndex = (int)sheepDesireNum;

			//Sheep sheep = new Sheep ();
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
