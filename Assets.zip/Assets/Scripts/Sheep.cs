﻿using UnityEngine;
using System.Collections;

public class Sheep : MonoBehaviour {

	public int m_DesireIndex = 0;
	public Color m_SheepColor;

	private Vector3 m_Direction;
	private float m_Timer = 0;
	private float m_Mover = 0;
	private float m_SpeedModifier = 1f;

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		m_Timer += Time.deltaTime * m_SpeedModifier;
		m_Mover += Time.deltaTime * 0.001f;

		if (m_Timer <= 6.0f) 
		{
			gameObject.transform.Translate (new Vector3(0, 0, 0.01f));
			//gameObject.GetComponent<Rigidbody>().AddForce(new Vector3(0, -7f, 0));
			//gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, m_Direction, m_Mover);
		}

		else 
		{
			m_Timer = 0;
			//m_Direction = new Vector3 (Random.Range(-1f, 1f) * 0.01f, 0, Random.Range(-1f, 1f) * 0.01f);
			m_Direction = new Vector3 (Random.Range(-10f, 10f), 0, Random.Range(-10f, 10f));

			Vector3 targetDirection = m_Direction - gameObject.transform.position;
			Vector3 targetRotation = Vector3.RotateTowards (gameObject.transform.forward, targetDirection, 360f, 0.0f);
			//gameObject.transform.rotation = Quaternion.LookRotation (targetRotation);
		} 
	}
}
