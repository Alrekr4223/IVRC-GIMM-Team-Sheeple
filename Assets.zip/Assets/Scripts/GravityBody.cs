﻿using UnityEngine;
using System.Collections;

// gravity code by mike loscocco
public class GravityBody : MonoBehaviour {

	public GravityAttractor m_CurrentAttraction;
	public Rigidbody m_ObjectBody;
	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void LateUpdate () 
	{
		if (m_CurrentAttraction != null && m_ObjectBody != null) 
		{
			m_CurrentAttraction.AttractSheep (m_ObjectBody);
		}
	}
}
